package com.example.bottomup

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetBehavior.BottomSheetCallback
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {


    private var bottomSheetBehavior: BottomSheetBehavior<*>? = null
    private var mTextView: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val bottomSheet = bottom_sheet

        bottomSheetBehavior = BottomSheetBehavior.from(bottomSheet)
        mTextView = txt_state

        bottomSheetBehavior?.peekHeight = 90

        val btn_exp = btn_exp
        val btn_clsp = btn_collasp

        btn_exp.setOnClickListener {
            bottomSheetBehavior?.setState(BottomSheetBehavior.STATE_EXPANDED)
        }

        btn_clsp.setOnClickListener {
            bottomSheetBehavior?.state = BottomSheetBehavior.STATE_COLLAPSED
        }

        bottomSheetBehavior?.setBottomSheetCallback(object : BottomSheetCallback() {
            override fun onStateChanged(view: View, i: Int) {
                when (i){
                    BottomSheetBehavior.STATE_COLLAPSED -> mTextView?.setText("Collapsed")
                    BottomSheetBehavior.STATE_DRAGGING -> mTextView?.setText("Dragging...")
                    BottomSheetBehavior.STATE_EXPANDED -> mTextView?.setText("Expanded")
                    BottomSheetBehavior.STATE_HIDDEN -> mTextView?.setText("Hidden")
                    BottomSheetBehavior.STATE_HALF_EXPANDED -> mTextView?.setText("Half Expanded")
                    BottomSheetBehavior.STATE_SETTLING -> mTextView?.setText("Settling...")
                }
            }
            override fun onSlide(view: View, v: Float) {
                mTextView?.setText("Sliding...")
            }
        })
    }
}